import tkinter as tk
from tkinter import Entry,  StringVar, END, CENTER

